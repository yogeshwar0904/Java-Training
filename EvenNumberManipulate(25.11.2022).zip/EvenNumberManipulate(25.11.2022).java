import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * If the number divisible by two those
 * numbers must be multiplied with 
 * eachother.
 */
public class EvenNumberManipulate {
    public static void main(String[] args) {
        int size;
        int [] numbers;
        Scanner scanner = new Scanner(System.in);
        boolean continueAgain = true;
        do {
            try {
                System.out.println("Enter the size of a array");
                size = scanner.nextInt();
                numbers = new int[size];
                System.out.println("Enter the number to initialize in array");
                for (int index = 0; index < size; index++) {
                    numbers[index] = scanner.nextInt();
                }
                manipulation(numbers);
                continueAgain = false;
            } catch (InputMismatchException exception) {
                System.out.println("Entered data is Invalid!!");
                scanner.skip("\r\n");
            }

        } while(continueAgain);
    }
    static void manipulation(int [] numbers) {  
        int evenNumberManipulate = 1;            
        for (int numberCopy : numbers) {
            if(numberCopy % 2 == 0){
                evenNumberManipulate = evenNumberManipulate * numberCopy;
            }
        }
        System.out.println("the manipulation of even numbers =" + evenNumberManipulate);
    }
}